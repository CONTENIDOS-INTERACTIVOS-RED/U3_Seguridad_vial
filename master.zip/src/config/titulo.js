module.exports = 'Seguimiento, auditoría y mejora continua de la seguridad vial laboral'
