<template lang="pug">
.curso-main-container.pb-3
  BannerInterno(:subTitulo="'3. Mejora continua del plan estratégico de seguridad vial'")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.overflow-hidden
    .row.mb-5
      .col-lg-8
        .bg-color-3.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/27.svg")
            .col-lg
              p.mb-0 La organización tiene la responsabilidad de definir e implementar acciones preventivas y correctivas basadas en los resultados obtenidos mediante indicadores, auditorías internas y visitas de verificación del PESV. Este proceso debe estar guiado por un compromiso firme con la mejora continua, garantizando que las acciones adoptadas sean pertinentes, oportunas y alineadas con los hallazgos detectados en cada fase de evaluación.
        p(data-aos="fade-left") La evolución de los pasos del PESV constituye una evidencia tangible del progreso en la gestión de la seguridad vial, y refleja tanto la eficacia de las acciones como el nivel de articulación con contratistas y demás partes interesadas. Acciones clave para evidenciar la mejora continua: 

      .col-lg-4.mb-3.mb-lg-0
        figure
          img.img-a.img-t(src="@/assets/curso/temas/28.png", data-aos="zoom-in")

    .bg-full-width.bg-fondo-slider.mb-5(data-aos="fade-right")
      .p-4.p-md-5
        SlyderA(tipo="b").bg-white
          .row.align-items-center.p-4.p-md-5
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/29.png")               
            .col-lg-7
              h5.mb-4 Análisis de siniestros viales 
              p Uso de análisis estadístico para detectar patrones, identificar áreas críticas y enfocar medidas de prevención.
          .row.align-items-center.p-4.p-md-5
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/30.png")               
            .col-lg-7
              h5.mb-4 Verificación de hallazgos 
              p Evaluación de la implementación efectiva de recomendaciones derivadas de auditorías internas y externas.
          .row.align-items-center.p-4.p-md-5
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/31.png")               
            .col-lg-7
              h5.mb-4 Cierre de planes de acción 
              p Asegurar el cierre oportuno de acciones correctivas surgidas de investigaciones de siniestros viales.
          .row.align-items-center.p-4.p-md-5
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/32.png")               
            .col-lg-7
              h5.mb-4 Simulacros y emergencias 
              p Seguimiento a simulacros para medir la capacidad de respuesta y activar planes de emergencia cuando sea necesario.
          .row.align-items-center.p-4.p-md-5
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/33.png")               
            .col-lg-7
              h5.mb-4 Planes de formación y trabajo 
              p Cumplimiento sistemático de programas de formación, sensibilización y acciones específicas del PESV.
          .row.align-items-center.p-4.p-md-5
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/34.png")               
            .col-lg-7
              h5.mb-4 Evaluación de desempeño 
              p Medición de factores de desempeño que permitan verificar avances y efectividad de las intervenciones.
          .row.align-items-center.p-4.p-md-5
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/35.png")               
            .col-lg-7
              h5.mb-4 Gestión del riesgo dinámico  
              p Monitoreo, valoración y tratamiento de variables cambiantes que inciden en la seguridad vial (vehículo, conductor, entorno, etc.).

    .row.mb-5
      .col-lg-8.j1.mb-3.mb-lg-0
        p(data-aos="fade-left") Estas acciones deben estar sustentadas en evidencia y orientadas a una gestión proactiva que se adapte a los cambios y evolución del contexto operativo. La mejora continua implica también:

        .bg-color-3.p-4.mb-4(data-aos="fade-left")
          ul.lista-ul--color.mb-0            
            li.d-flex
              i.far.fa-arrow-alt-circle-right.color-1
              p.mb-0 La revisión periódica de indicadores para detectar desviaciones y oportunidades de mejora.
            li.d-flex
              i.far.fa-arrow-alt-circle-right.color-1
              p.mb-0 El ajuste de estrategias con base en resultados obtenidos.
            li.d-flex
              i.far.fa-arrow-alt-circle-right.color-1
              p.mb-0 La consolidación de una cultura organizacional centrada en la seguridad vial, que involucre activamente a todos los actores.
        p(data-aos="fade-left") La mejora continua en seguridad vial no es un estado final, sino un proceso dinámico, articulado y sistémico, cuyo propósito es reducir de manera sostenida los riesgos y siniestros viales. Una gestión fundamentada en la evidencia, apoyada por una evaluación constante y guiada por un liderazgo comprometido, permitirá a la organización alcanzar niveles superiores de protección, eficiencia y bienestar para trabajadores, contratistas y la comunidad en general.
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/36.png", data-aos="zoom-in")  
    .bg-full-width.border-top.color-primario
      .p-4.p-md-5
        h2(data-aos="fade-left") MATERIAL COMPLEMENTARIO
        .row.material-complementario
          .col-12.col-md-6.col-lg-7
            p Los invitamos a explorar el material complementario de este curso, en esta sección encontrará recursos que le permitirán profundizar  y enriquecer su aprendizaje en los temas tratados en esta unidad.

            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://safetya.co/estructura-del-plan-estrategico-de-seguridad-vial/" target="_blank" rel="noopener noreferrer") Riesgo vial. (2016). Estructura del Plan Estratégico de Seguridad Vial. SafetYA. 

            p.d-flex.my-4
              img.me-3(src='@/assets/template/book.svg' :style="{'max-width':'16px'}")
              a(href="https://mintransporte.gov.co/ " target="_blank" rel="noopener noreferrer") Mintransporte. (s.f.). Ministerio de Transporte. 

            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://open.spotify.com/episode/2DwT6gUNAfS8dtHoNpsjEr" target="_blank" rel="noopener noreferrer") SGI  empresarial. (2024). Construcción y seguridad en las carreteras. Estrategìas ISO 39001 para prevenir accidentes.  Capítulo 5 (podcast).

          .col-12.col-md-6.col-lg-3.offset-lg-1
            figure
              img(src='@/assets/componentes/material-complementario.svg', alt='')
  
</template>

<script>
export default {
  name: 'Tema3',
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
}
</script>

<style lang="sass"></style>
