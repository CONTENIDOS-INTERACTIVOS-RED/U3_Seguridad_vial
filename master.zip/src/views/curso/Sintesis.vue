<template lang="pug">
  .curso-main-container.creditos-vista
    BannerInterno(subTitulo="SÍNTESIS")
    .container.tarjeta.tarjeta--blanca.p-4.p-md-5
      p(data-aos="fade-up").mb-5 El seguimiento, la auditoría y la mejora continua en la seguridad vial laboral son elementos fundamentales para garantizar la efectividad de las acciones implementadas y promover un entorno de trabajo cada vez más seguro y responsable. 

      .row.justify-content-center
        .col-lg-12.mb-5
          figure.bg-color-sintesis.p-5.brounded
            img(src='@/assets/curso/sintesis.svg', alt='', data-aos="zoom-in")
</template>
