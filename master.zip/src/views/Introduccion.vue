<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5

    .row.justify-content-center.mb-5           
      .col-lg-4
        .bg-color-1.p-3.h-100.brounded.j1
          p(data-aos="fade-down").mb-0 La seguridad vial en el entorno laboral, es un componente esencial para la protección de los trabajadores, especialmente en sectores donde la movilidad es una actividad cotidiana. Más allá de cumplir con la normativa, se trata de adoptar una cultura organizacional que priorice la prevención, la responsabilidad compartida y la mejora constante. Esta unidad busca fortalecer las capacidades de los profesionales para gestionar el Plan Estratégico de Seguridad Vial (PESV), desde un enfoque integral, articulando acciones preventivas con herramientas de seguimiento y evaluación.
      .col-lg-4.my-4.my-lg-0
        figure
          img.img-a.img-t(src='@/assets/curso/temas/1.png', alt='', data-aos="zoom-in")          
      .col-lg-4
        .bg-color-2.p-3.h-100.brounded.j1
          p(data-aos="fade-down").mb-0 A través del estudio de esta unidad, los participantes comprenderán cómo implementar mecanismos de control como el monitoreo de indicadores claves, la elaboración de informes, las auditorías internas y la integración con otros sistemas de gestión (ISO 39001, ISO 45001, ISO 14001). Se abordarán criterios técnicos para diseñar e interpretar indicadores, analizar datos relevantes, documentar hallazgos y ejecutar acciones de mejora que realmente impacten en la reducción de riesgos viales. Asimismo, se reflexionará sobre el rol activo de los distintos actores de la organización, en la construcción de entornos laborales más seguros.

    .bg-full-width.bg-color-3.p-4.mb-4(data-aos="fade-left")
      .row.align-items-start
        .col-lg-auto
          img.img-a.img-t(src="@/assets/curso/temas/2.svg")
        .col-lg
          p.mb-0 Finalmente, la unidad fomenta una visión crítica y estratégica de la seguridad vial, incentivando la participación del personal, el análisis de variables dinámicas de riesgo y la comunicación efectiva de resultados y aprendizajes. Con esta formación, se espera que los profesionales sean capaces de liderar procesos de transformación en sus organizaciones, optimizando los recursos disponibles, consolidando prácticas seguras y generando impactos positivos tanto en el ámbito laboral como en la comunidad.
</template>
